// WindowBar - 窗口悬浮栏
// 编译: swiftc -o ~/Desktop/WindowBar main.swift && ~/Desktop/WindowBar &
// 权限: 系统设置 → 隐私 → 辅助功能 → 添加 WindowBar

import Cocoa
import SwiftUI

// MARK: - CF 桥接常量
private let kWindowLayer = kCGWindowLayer as String
private let kWindowBounds = kCGWindowBounds as String
private let kWindowOwnerPID = kCGWindowOwnerPID as String
private let kWindowName = kCGWindowName as String

// MARK: - 应用模型
// MARK: - 顶层工具函数
/// 用位置+尺寸判断 AX 窗口是否为真实用户窗口
private func isUserWindowAX(_ w: AXUIElement) -> Bool {
    var posRef: CFTypeRef?, sizeRef: CFTypeRef?
    guard AXUIElementCopyAttributeValue(w, kAXPositionAttribute as CFString, &posRef) == .success,
          AXUIElementCopyAttributeValue(w, kAXSizeAttribute as CFString, &sizeRef) == .success else {
        return false
    }
    var pos = CGPoint.zero; var size = CGSize.zero
    AXValueGetValue(posRef as! AXValue, .cgPoint, &pos)
    AXValueGetValue(sizeRef as! AXValue, .cgSize, &size)
    guard size.width > 30, size.height > 30 else { return false }
    // 排除幽灵窗口：位置 (0,0) 且尺寸接近全屏
    let screenSize = NSScreen.main?.frame.size ?? CGSize(width: 2048, height: 1152)
    let isGhost = pos.x == 0 && pos.y == 0 &&
        abs(size.width - screenSize.width) < 10 &&
        abs(size.height - screenSize.height) < 10
    return !isGhost
}

// MARK: - 应用模型
struct AppIconModel: Identifiable, Hashable {
    let id = UUID()
    let pid: pid_t
    let name: String
    let icon: NSImage?
    let bundleId: String
    let hasNormal: Bool    // 有可见（非最小化）窗口
    let hasMinimized: Bool // 有最小化窗口
    let windowCount: Int
    
    func hash(into h: inout Hasher) {
        h.combine(pid)
        h.combine(bundleId)
    }
    static func == (l: Self, r: Self) -> Bool {
        l.pid == r.pid && l.bundleId == r.bundleId
    }
}

// MARK: - 窗口扫描
class WindowScanner {
    func scan() -> [AppIconModel] {
        var results: [AppIconModel] = []
        for app in NSWorkspace.shared.runningApplications {
            guard app.activationPolicy == .regular, let bid = app.bundleIdentifier else { continue }
            let pid = app.processIdentifier
            
            // 通过 AX API 获取标准窗口（排除 AXUnknown 等非用户窗口）
            let axWindows = getAXWindows(pid: pid)
            let userWindows = axWindows.filter { isUserWindow($0) }
            
            guard !userWindows.isEmpty else { continue }
            
            let axMinimized = userWindows.filter { isAXMinimized($0) }.count
            let hasMinimized = axMinimized > 0
            
            // 通过 CGWindowList 判断是否有可见（非最小化）窗口在当前空间
            let cgw = cgWindows(pid: pid)
            let hasVisibleCG = cgw.contains { w in
                guard let b = w[kWindowBounds] as? [String: Any] else { return false }
                let ww = b["Width"] as? CGFloat ?? 0
                let wh = b["Height"] as? CGFloat ?? 0
                guard ww > 50, wh > 50, ww < 5000, wh < 5000 else { return false }
                let layer = w[kWindowLayer] as? Int32 ?? 0
                guard layer >= -100 && layer <= 100 else { return false }
                return true
            }
            
            results.append(AppIconModel(
                pid: pid, name: app.localizedName ?? bid,
                icon: app.icon, bundleId: bid,
                hasNormal: hasVisibleCG,
                hasMinimized: hasMinimized,
                windowCount: userWindows.count
            ))
        }
        return results.sorted { $0.name < $1.name }
    }
    
    private func cgWindows(pid: pid_t) -> [[String: Any]] {
        let list = CGWindowListCopyWindowInfo(.optionAll, kCGNullWindowID) as? [[String: Any]] ?? []
        return list.filter { ($0[kWindowOwnerPID] as? pid_t) == pid }
    }
    
    /// 获取 AX 窗口列表
    private func getAXWindows(pid: pid_t) -> [AXUIElement] {
        let el = AXUIElementCreateApplication(pid)
        var ref: CFTypeRef?
        guard AXUIElementCopyAttributeValue(el, kAXWindowsAttribute as CFString, &ref) == .success,
              let wins = ref as? [AXUIElement] else { return [] }
        return wins
    }
    
    /// 判断是真实用户窗口（不是后台幽灵窗口）
    /// 幽灵窗口特点：位置 (0,0)，全屏尺寸，如 QSpace 等应用关闭后遗留的
    private func isUserWindow(_ w: AXUIElement) -> Bool {
        return isUserWindowAX(w)
    }
    
    private func isAXMinimized(_ w: AXUIElement) -> Bool {
        var mr: CFTypeRef?
        guard AXUIElementCopyAttributeValue(w, kAXMinimizedAttribute as CFString, &mr) == .success,
              let m = mr as? Bool, m else { return false }
        return true
    }
}

// MARK: - 窗口管理器
class WindowManager: ObservableObject {
    @Published var apps: [AppIconModel] = []
    private let scanner = WindowScanner()
    private var timer: Timer? = nil
    private var prev: [AppIconModel] = []
    
    init() { scan(); timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in self?.scan() } }
    func stop() { timer?.invalidate(); timer = nil }
    
    private func scan() {
        let cur = scanner.scan()
        guard cur != prev else { return }
        prev = cur
        DispatchQueue.main.async { [weak self] in self?.apps = cur }
    }
    
    /// 点击图标：Windows 风格的切换行为
    /// - 如果该应用在最前 → 全部最小化
    /// - 如果该应用不在最前 → 聚焦到最前
    func toggleApp(_ app: AppIconModel) {
        guard let nsa = NSRunningApplication(processIdentifier: app.pid) else { return }
        
        let userWins = getUserWindows(pid: app.pid)
        let visibleWins = userWins.filter { w in
            var mr: CFTypeRef?
            guard AXUIElementCopyAttributeValue(w, kAXMinimizedAttribute as CFString, &mr) == .success,
                  let m = mr as? Bool else { return false }
            return !m
        }
        
        // 判断该应用是否在最前
        let isFrontmost = nsa.isActive
        
        if isFrontmost && !visibleWins.isEmpty {
            // 在前且可见窗口存在 → 全部最小化
            for w in visibleWins {
                AXUIElementSetAttributeValue(w, kAXMinimizedAttribute as CFString, true as CFTypeRef)
            }
        } else {
            // 不在前 或 无可见窗口 → 聚焦到最前
            // 先反最小化，再 activate（系统处理窗口提升）
            for w in userWins {
                var mr: CFTypeRef?
                guard AXUIElementCopyAttributeValue(w, kAXMinimizedAttribute as CFString, &mr) == .success,
                      let m = mr as? Bool, m else { continue }
                AXUIElementSetAttributeValue(w, kAXMinimizedAttribute as CFString, false as CFTypeRef)
                break
            }
            nsa.activate(options: .activateIgnoringOtherApps)
        }
        
        scanImmediately()
    }
    
    /// 立即扫描并同步更新 apps
    private func scanImmediately() {
        let cur = scanner.scan()
        prev = cur
        DispatchQueue.main.async { [weak self] in
            self?.apps = cur
        }
    }
    
    /// 关闭应用的所有用户窗口（模拟点击红 ×），不退出应用
    func closeWindows(_ app: AppIconModel) {
        let wins = getUserWindows(pid: app.pid)
        for w in wins {
            // 获取关闭按钮并点击（比直接 AXClose 更可靠）
            var closeRef: CFTypeRef?
            let result = AXUIElementCopyAttributeValue(w, "AXCloseButton" as CFString, &closeRef)
            if result == .success {
                let closeBtn = closeRef as! AXUIElement
                AXUIElementPerformAction(closeBtn, "AXPress" as CFString)
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
            self?.scanImmediately()
        }
    }
    
    /// 最小化该应用的所有用户窗口
    private func minimizeAllWindows(pid: pid_t) {
        let wins = getUserWindows(pid: pid)
        for w in wins {
            var minRef: CFTypeRef?
            guard AXUIElementCopyAttributeValue(w, kAXMinimizedAttribute as CFString, &minRef) == .success,
                  let isMin = minRef as? Bool, !isMin else { continue }
            AXUIElementSetAttributeValue(w, kAXMinimizedAttribute as CFString, true as CFTypeRef)
        }
    }
    
    /// 反最小化一个窗口
    private func deminimizeOneWindow(pid: pid_t) {
        let wins = getUserWindows(pid: pid)
        for w in wins {
            var mr: CFTypeRef?
            guard AXUIElementCopyAttributeValue(w, kAXMinimizedAttribute as CFString, &mr) == .success,
                  let m = mr as? Bool, m else { continue }
            AXUIElementSetAttributeValue(w, kAXMinimizedAttribute as CFString, false as CFTypeRef)
            return
        }
    }
    
    /// 获取用户窗口列表（过滤幽灵窗口）
    private func getUserWindows(pid: pid_t) -> [AXUIElement] {
        let el = AXUIElementCreateApplication(pid)
        var ref: CFTypeRef?
        guard AXUIElementCopyAttributeValue(el, kAXWindowsAttribute as CFString, &ref) == .success,
              let wins = ref as? [AXUIElement] else { return [] }
        return wins.filter { isUserWindowAX($0) }
    }
}

// MARK: - 锁状态共享
class LockState: ObservableObject {
    @Published var isLocked: Bool {
        didSet { UserDefaults.standard.set(isLocked, forKey: "panelLocked") }
    }
    init() { isLocked = UserDefaults.standard.bool(forKey: "panelLocked") }
}

// MARK: - 悬浮栏 SwiftUI 视图
struct FloatBar: View {
    @ObservedObject var wm: WindowManager
    @StateObject private var lockState = LockState()
    @State private var hoverLock: Bool = false
    @State private var hoverIdx: Int? = nil
    
    let iconSize: CGFloat = 38
    let innerPadding: CGFloat = 8
    let vPadding: CGFloat = 8
    let spacing: CGFloat = 6
    
    var body: some View {
        HStack(spacing: spacing) {
            // 锁按钮
            Button {
                lockState.isLocked.toggle()
                // 同步到面板
                if let panel = NSApplication.shared.windows.first(where: { $0 is FloatPanel }) as? FloatPanel {
                    panel.syncLockState(lockState.isLocked)
                }
            } label: {
                Image(systemName: lockState.isLocked ? "lock.fill" : "lock.open")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(lockState.isLocked ? .white : .secondary.opacity(0.5))
                    .frame(width: 22, height: 22)
                    .background(
                        RoundedRectangle(cornerRadius: 5)
                            .fill(lockState.isLocked ? Color.accentColor.opacity(0.3) : Color.clear)
                    )
            }
            .buttonStyle(.plain)
            .help(lockState.isLocked ? "已锁定位置，点击解锁" : "未锁定，可拖拽")
            .onHover { h in hoverLock = h; if h { NSCursor.pointingHand.push() } else { NSCursor.pop() } }
            
            if !wm.apps.isEmpty {
                Rectangle().fill(Color.white.opacity(0.08)).frame(width: 1, height: iconSize * 0.5)
            }
            
            if wm.apps.isEmpty {
                Image(systemName: "square.on.square")
                    .font(.system(size: 18))
                    .foregroundColor(.secondary.opacity(0.5))
                    .padding(.horizontal, 10)
            }
            ForEach(Array(wm.apps.enumerated()), id: \.element.id) { i, app in
                btn(app: app, idx: i)
                if i < wm.apps.count - 1 {
                    Rectangle().fill(Color.white.opacity(0.08)).frame(width: 1, height: iconSize * 0.5)
                }
            }
        }
        .padding(.horizontal, innerPadding)
        .padding(.vertical, vPadding)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(.ultraThinMaterial)
                .shadow(color: .black.opacity(0.3), radius: 10, x: 0, y: 5)
        )
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.12), lineWidth: 0.5))
        .gesture(lockState.isLocked ? nil : DragGesture().onChanged { v in
            guard let panel = NSApplication.shared.windows.first(where: { $0 is FloatPanel }) as? FloatPanel else { return }
            var f = panel.frame; f.origin.x += v.translation.width; f.origin.y -= v.translation.height
            panel.setFrame(f, display: true)
        }.onEnded { _ in
            if let panel = NSApplication.shared.windows.first(where: { $0 is FloatPanel }) as? FloatPanel {
                UserDefaults.standard.set(panel.frame.origin.x, forKey: "wx")
                UserDefaults.standard.set(panel.frame.origin.y, forKey: "wy")
            }
        })
    }
    
    @ViewBuilder
    func btn(app: AppIconModel, idx: Int) -> some View {
        Button {
            wm.toggleApp(app)
        } label: {
            ZStack(alignment: .bottom) {
                if let icon = app.icon {
                    Image(nsImage: icon)
                        .resizable().interpolation(.high)
                        .frame(width: iconSize, height: iconSize)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(hoverIdx == idx ? Color.accentColor.opacity(0.5) : .clear, lineWidth: 2))
                        .shadow(color: .black.opacity(0.15), radius: 2, x: 0, y: 1)
                } else {
                    RoundedRectangle(cornerRadius: 8).fill(Color.gray.opacity(0.25)).frame(width: iconSize, height: iconSize)
                        .overlay(Text(String(app.name.prefix(1))).font(.title3).foregroundColor(.secondary))
                }
                // 状态指示器 - 在图标右下角，更大更明显
                if app.hasMinimized && app.hasNormal {
                    // 部分最小化 - 蓝色粗条，右下斜角
                    Rectangle()
                        .fill(Color.blue)
                        .frame(width: iconSize * 0.55, height: 5)
                        .cornerRadius(2.5)
                        .shadow(color: .blue.opacity(0.5), radius: 2)
                        .offset(x: iconSize * 0.22, y: -2)
                } else if !app.hasNormal && app.hasMinimized {
                    // 全部最小化 - 橙色粗条
                    Rectangle()
                        .fill(Color.orange)
                        .frame(width: iconSize * 0.55, height: 5)
                        .cornerRadius(2.5)
                        .shadow(color: .orange.opacity(0.5), radius: 2)
                        .offset(x: iconSize * 0.22, y: -2)
                } else if app.hasNormal && !app.hasMinimized {
                    // 全部正常 - 绿色粗条
                    Rectangle()
                        .fill(Color.green)
                        .frame(width: iconSize * 0.55, height: 5)
                        .cornerRadius(2.5)
                        .shadow(color: .green.opacity(0.5), radius: 2)
                        .offset(x: iconSize * 0.22, y: -2)
                }
            }
        }
        .buttonStyle(.plain)
        .help(buildHelp(app: app))
        .contextMenu {
            Button {
                wm.closeWindows(app)
            } label: {
                Label("关闭窗口", systemImage: "xmark")
            }
            Divider()
            Button {
                // 这里以后可以加其他功能
            } label: {
                Label("\(app.name) (\(app.windowCount)个窗口)", systemImage: "info.circle")
            }
            .disabled(true)
        }
        .onHover { h in
            hoverIdx = h ? idx : nil
            if h { NSCursor.pointingHand.push() } else { NSCursor.pop() }
        }
    }
    
    func buildHelp(app: AppIconModel) -> String {
        var parts = [app.name]
        if app.hasMinimized { parts.append("有最小化窗口") }
        if app.hasNormal { parts.append("点击最小化") }
        else { parts.append("点击还原") }
        parts.append("\(app.windowCount)个窗口")
        return parts.joined(separator: " · ")
    }
}

// MARK: - 自定义 NSView 包装
class FloatBarView: NSView {
    private let wm = WindowManager()
    
    override init(frame: NSRect) {
        super.init(frame: frame)
        setup()
    }
    required init?(coder: NSCoder) { fatalError() }
    
    private func setup() {
        let bar = FloatBar(wm: wm)
        let hv = NSHostingView(rootView: bar)
        hv.translatesAutoresizingMaskIntoConstraints = false
        addSubview(hv)
        NSLayoutConstraint.activate([
            hv.centerXAnchor.constraint(equalTo: centerXAnchor),
            hv.centerYAnchor.constraint(equalTo: centerYAnchor),
            hv.leadingAnchor.constraint(greaterThanOrEqualTo: leadingAnchor, constant: 4),
            hv.trailingAnchor.constraint(lessThanOrEqualTo: trailingAnchor, constant: -4),
            hv.topAnchor.constraint(equalTo: topAnchor),
            hv.bottomAnchor.constraint(equalTo: bottomAnchor),
        ])
    }
}

// MARK: - 浮动面板
class FloatPanel: NSPanel {
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }
    
    /// 同步锁定状态
    func syncLockState(_ locked: Bool) {
        isMovableByWindowBackground = !locked
    }
    
    init() {
        let s = NSScreen.main?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1440, height: 900)
        let w: CGFloat = 420, h: CGFloat = 62
        let x = (s.width - w) / 2
        let y = s.maxY - h - 14
        super.init(contentRect: NSRect(x: x, y: y, width: w, height: h),
                   styleMask: [.borderless, .nonactivatingPanel, .fullSizeContentView],
                   backing: .buffered, defer: false)
        isFloatingPanel = true
        level = .floating
        collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]
        isOpaque = false
        backgroundColor = .clear
        hasShadow = false
        ignoresMouseEvents = false
        isMovableByWindowBackground = true
        titlebarAppearsTransparent = true
        
        let barView = FloatBarView(frame: NSRect(x: 0, y: 0, width: w, height: h))
        barView.autoresizingMask = [.width, .height]
        contentView?.addSubview(barView)
        
        setFrame(NSRect(x: x, y: y, width: w, height: h), display: true)
    }
}

// MARK: - App Delegate
class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
    var panel: FloatPanel?
    var statusItem: NSStatusItem?
    
    func applicationDidFinishLaunching(_ n: Notification) {
        _ = AXIsProcessTrustedWithOptions([kAXTrustedCheckOptionPrompt.takeRetainedValue(): true] as CFDictionary)
        
        panel = FloatPanel()
        panel?.delegate = self
        panel?.orderFrontRegardless()
        
        // 菜单栏图标
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        if let b = statusItem?.button {
            b.image = NSImage(systemSymbolName: "square.on.square.dashed", accessibilityDescription: "窗口栏")
        }
        let m = NSMenu()
        let pm = NSMenuItem(title: "位置", action: nil, keyEquivalent: "")
        let ps = NSMenu()
        ps.addItem(withTitle: "顶中", action: #selector(moveTC), keyEquivalent: "")
        ps.addItem(withTitle: "顶左", action: #selector(moveTL), keyEquivalent: "")
        ps.addItem(withTitle: "顶右", action: #selector(moveTR), keyEquivalent: "")
        ps.addItem(withTitle: "底中", action: #selector(moveBC), keyEquivalent: "")
        ps.addItem(withTitle: "底左", action: #selector(moveBL), keyEquivalent: "")
        ps.addItem(withTitle: "底右", action: #selector(moveBR), keyEquivalent: "")
        pm.submenu = ps
        m.addItem(pm)
        m.addItem(NSMenuItem.separator())
        m.addItem(withTitle: "重新加载", action: #selector(reload), keyEquivalent: "r")
        m.addItem(withTitle: "退出", action: #selector(quitApp), keyEquivalent: "q")
        statusItem?.menu = m
        
        NotificationCenter.default.addObserver(self, selector: #selector(showPanel),
                                               name: NSWorkspace.activeSpaceDidChangeNotification, object: nil)
        
        if let x = UserDefaults.standard.object(forKey: "wx") as? CGFloat,
           let y = UserDefaults.standard.object(forKey: "wy") as? CGFloat {
            panel?.setFrameOrigin(NSPoint(x: x, y: y))
        }
    }
    
    @objc func showPanel() { panel?.orderFrontRegardless() }
    
    @objc func moveTC() { moveTo(h: 0.5, v: 1.0) }
    @objc func moveTL() { moveTo(h: 0.0, v: 1.0) }
    @objc func moveTR() { moveTo(h: 1.0, v: 1.0) }
    @objc func moveBC() { moveTo(h: 0.5, v: 0.0) }
    @objc func moveBL() { moveTo(h: 0.0, v: 0.0) }
    @objc func moveBR() { moveTo(h: 1.0, v: 0.0) }
    
    func moveTo(h: CGFloat, v: CGFloat) {
        guard let p = panel, let s = NSScreen.main?.visibleFrame else { return }
        let mg: CGFloat = 12, pw = p.frame.width, ph = p.frame.height
        let x: CGFloat = h <= 0.1 ? s.minX + mg : (h >= 0.9 ? s.maxX - pw - mg : s.midX - pw / 2)
        let y: CGFloat = v <= 0.1 ? s.minY + mg : (v >= 0.9 ? s.maxY - ph - mg : s.midY - ph / 2)
        NSAnimationContext.runAnimationGroup { ctx in
            ctx.duration = 0.2; ctx.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            p.animator().setFrameOrigin(NSPoint(x: x, y: y))
        }
    }
    
    @objc func reload() {
        let f = panel?.frame ?? NSRect.zero
        panel?.close()
        panel = FloatPanel()
        panel?.setFrame(f, display: true)
        panel?.delegate = self
        panel?.orderFrontRegardless()
    }
    
    @objc func quitApp() {
        if let p = panel { UserDefaults.standard.set(p.frame.origin.x, forKey: "wx"); UserDefaults.standard.set(p.frame.origin.y, forKey: "wy") }
        NSApplication.shared.terminate(nil)
    }
    
    func windowDidMove(_ n: Notification) {
        guard let p = n.object as? NSWindow else { return }
        UserDefaults.standard.set(p.frame.origin.x, forKey: "wx")
        UserDefaults.standard.set(p.frame.origin.y, forKey: "wy")
    }
}

// 入口
let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.accessory)
app.run()
